import enum
class TipoContract(enum.Enum):
    LEASING = 1
    RENTING = 2
    FINANCING = 3
    FACTORING = 4
   


    def __str__(self):
        return self.name
        #+" "+ str(self.value)

    def get_tipo_contrato(inputstr):
        if (inputstr == "1" or inputstr.lower() == "LEASING".lower()):
            return TipoContract.LEASING
        elif (inputstr == "2" or inputstr.lower() == "RENTING".lower()):
            return TipoContract.RENTING
        elif (inputstr == "3" or inputstr.lower() == "FINANCING".lower()):
            return TipoContract.FINANCING
        elif (inputstr == "4" or inputstr.lower() == "FACTORING".lower()):
            return TipoContract.FACTORING
       
        else:
            raise Exception("tipo not valid")