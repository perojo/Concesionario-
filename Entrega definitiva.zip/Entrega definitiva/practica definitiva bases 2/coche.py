# -*- coding: utf-8 -*-
class Coche(): 
    
    def __init__(self, id, fabricante, tipo, precio, id_concesionario, vendido):
            self.__id = id
            self.__precio = precio
            self.__fabricante = fabricante
            self.__tipo = tipo 
            self.__id_concesionario = id_concesionario
            self.__vendido = vendido
            
            #VARIABLES FINALES
            if not isinstance (id, int): 
                raise TypeError("Error id should be an integer")
            elif id<=0: 
                raise ValueError("Error.The id cannot be a negative number and 0")
            else:   
                self.__id= id

            if not isinstance(precio, int): 
                raise TypeError("Error precio should be a integer")
            else:
                self.__precio= precio
        
            if not isinstance(fabricante, str): 
                raise TypeError("Error. fabricante must be a string")
            else: 
                self.__fabricante= fabricante
            
            if not isinstance (id_concesionario, int): 
                raise TypeError("Error id_concesionario should be an integer")
            elif id<=0: 
                raise ValueError("Error.The id_concesionario cannot be a negative number and 0")
            else:   
                self.__id_conceisonario= id_concesionario

            if not isinstance (vendido, bool): 
                raise TypeError("Error vendido should be  a boolean")
            else:   
                self.__vendido= vendido
    
    def __str__(self):
        return "ID: "+ str(self.__id) + "\tfabricante: " + str(self.__fabricante) + "\ttipo: " + str(self.__tipo)+ "\tprecio: " + str(self.__precio) + "\tid_concesionario: " + str(self.__id_concesionario) + "\tvendido: " + str(self.__vendido)  

    def get_id(self):
        '''
        Funcion que permiten acceder al valor de un atributo.
        :param self: se refiere al objeto instanciado de esa clase sobre el cual se está invocando dicho método.
        '''
        return self.__id
  

