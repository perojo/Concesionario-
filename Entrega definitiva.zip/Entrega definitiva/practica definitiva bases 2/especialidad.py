import enum

class Especialidad(enum.Enum):
    ELECTROMECANICO = 1
    MECANICO_DE_MOTORES = 2
    REPARADOR_DE_SISTEMAS_NEUMATICOS = 3
    REPARADOR_DE_FRENOS = 4

    def __str__(self):
        return self.name
        #+" "+ str(self.value)
    
    def get_especialidad(self,inputstr):
        if (inputstr == "1" or inputstr.lower() == "Electromecanico".lower()):
            return Especialidad.ELECTROMECANICO
        elif (inputstr == "2" or inputstr.lower() == "Mecanico_de_motores".lower()):
            return Especialidad.MECANICO_DE_MOTORES
        elif (inputstr == "3" or inputstr.lower() == "Reparador_de_sistemas_mecanicos".lower()):
            return Especialidad.REPARADOR_DE_SISTEMAS_NEUMATICOS
        elif (inputstr == "4" or inputstr.lower() == "Reparador_de_frenos".lower()):
            return Especialidad.REPARADOR_DE_FRENOS
        else:
            raise Exception("Especialidad not valid")
