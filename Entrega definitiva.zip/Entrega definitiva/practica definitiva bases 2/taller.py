# -*- coding: utf-8 -*-
class Taller(): 
    
    def __init__(self, id, lugar, id_concesionario):
            self.__id = id
            self.__lugar = lugar
            self.__id_conceisonario = id_concesionario

            #VARIABLES FINALES
            if not isinstance (id, int): 
                raise TypeError("Error id should be an integer")
            elif id<=0: 
                raise ValueError("Error.The id cannot be a negative number and 0")
            else:   
                self.__id= id

            if not isinstance(lugar, str): 
                raise TypeError("Error. lugar must be a string")
            else: 
                self.__lugar= lugar
            
            if not isinstance (id_concesionario, int): 
                raise TypeError("Error id_conncesionario should be an integer")
            elif id<=0: 
                raise ValueError("Error.The id_concesionario cannot be a negative number and 0")
            else:   
                self.__id_conceisonario= id_concesionario