# -*- coding: utf-8 -*-
import datetime
class Contrato(): 
    
    def __init__(self, id, fecha, tipo, id_cliente, id_coche, id_concesioanrio):
        self.__id = id
        self.__fecha = fecha
        self.__tipo = tipo
        self.__id_cliente = id_cliente
        self.__id_coche = id_coche
        self.__id_conceisonario = id_concesioanrio

        #VARIABLES FINALES
        if not isinstance (id, int): 
            raise TypeError("Error.The id must be an integer")
        elif id <=0: 
            raise ValueError("Error.The id cannot be a negative number and 0")
        else:   
            self.__id= id
        
        if not isinstance(fecha, date.Date): 
            raise TypeError("Error. fecha should be a date")
        else: 
            self.__fecha= fecha
        
        if not isinstance (id_cliente, int): 
            raise TypeError("Error.The id_cliente must be an integer")
        elif id<=0: 
            raise ValueError("Error.The id_cliente cannot be a negative number and 0")
        else:   
            self.__id_cliente= id_cliente

        if not isinstance (id_coche, int): 
            raise TypeError("Error.The id_coche must be an integer")
        elif id<=0: 
            raise ValueError("Error.The id_coche cannot be a negative number and 0")
        else:   
            self.__id_coche= id_coche

        if not isinstance (id_concesioanrio, int): 
            raise TypeError("Error.The id_concesionario must be an integer")
        elif id<=0: 
            raise ValueError("Error.The id_concesionario cannot be a negative number and 0")
        else:   
            self.__id_conceisonario= id_concesioanrio

            