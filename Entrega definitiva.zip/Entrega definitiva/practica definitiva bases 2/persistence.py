from logging import exception
from re import A
from mysql.connector.utils import linux_distribution
from concesionario import Concesionario
from coche import Coche
from os import DirEntry
import mysql.connector
from cliente import Cliente
import datetime
from tipo_contract import TipoContract

cnx = None
database = "lossantoskustoms"

try:
    cnx = mysql.connector.connect(host = 'localhost', user = 'root', passwd = 'Ordenador06', database = 'lossantoskustoms')
    print(cnx)
except mysql.connector.Error as err:
    if err.errno == mysql.connector.errorcode.ER_ACCESS_DENIED_ERROR:
        print('hay un fallo en el nombre de usuario y/o contraseña')
    elif err.errno == mysql.connector.errorcode.ER_BAD_DB_ERROR:
        print('Database no existe')
    else:
        print(err)


#2.- Ver que coches ha arreglado un mecanico en concreto
def show_repaired_car_mecanic():
    '''
    Función para ver que coches ha arreglado un mecanico en concreto, dentro de nuestra base de datos.
    
    '''
    try:
        cursor = cnx.cursor()
        id_mecanico = (input("introduzca  el id del mecanico que ha arregaldo los coches que quieres ver: "))
        query = ("select * from Coche inner join Coche_Mecanicos c on Coche.id = c.id_coche where c.id_mecanicos ="+ str(id_mecanico)+";")
        data_query = id_mecanico
        cursor.execute(query, data_query)
        resultado = cursor.fetchall( )  
        print("las coches arreglados por el mecanico escogido son: ")
        for i in resultado:
            id = i[0]
            fabricante = i[1]
            tipo= i[2]
            precio = i[3]
            id_concesionario = i[4]
            vendido = i[5]
            objeto_coche= Coche(id ,fabricante,tipo, int(precio), id_concesionario,bool(vendido))
            print (objeto_coche)
            cursor.close()
        
    except Exception:
        return print("Se ha producido un error")  
            
    
    

#3.- Ver que coches se han arreglado en un taller       
def show_repaired_car_garage():
    '''
    Función para ver que coches ha arreglado un taller en concreto, dentro de nuestra base de datos.
    
    '''
    try:
        cursor = cnx.cursor()

        id_taller = input("introduzca  el id del taller que ha arregaldo los coches que quieres ver: ")
        query = (" select Coche.* from Coche inner join Coche_Mecanicos c on Coche.id = c.id_coche inner join mecanicos m on c.id_mecanicos = m.id where m.id_taller = " + str(id_taller)+";")
        data_query = id_taller
        cursor.execute(query, data_query)
        resultado = cursor.fetchall( ) 
        print("las coches arreglados en el taller escogido son: ")
        for i in resultado:
            id = i[0]
            fabricante = i[1]
            tipo= i[2]
            precio = i[3]
            id_concesionario = i[4]
            vendido = i[5]
            objeto_coche= Coche(id ,fabricante,tipo, int(precio), id_concesionario,bool(vendido))
            print (objeto_coche)
            cursor.close()
        

    except Exception:
        return print("Se ha producido un error")  

#4 ver vehiculos de toda la cadena de concesionarios
def get_car():
    '''
    Función para ver los coches de toda la cadena de concesionarios, dentro de nuestra base de datos.
    
    '''
    try:
        cursor= cnx.cursor()
        query= ("select * from coche where vendido= False;")
        coche_lista =[ ]
        cursor.execute(query)
        resultado = cursor.fetchall( ) 
        print("las vehiculos disponibles en los concesionarios son: ")
        for i in resultado:
            id = i[0]
            fabricante = i[1]
            tipo= i[2]
            precio = i[3]
            id_concesionario = i[4]
            vendido = i[5]
            objeto_coche= Coche(id ,fabricante,tipo, int(precio), id_concesionario,bool(vendido))
            print (objeto_coche)
        cursor.close()
        return coche_lista

    except Exception:
        return print("Se ha producido un error") 

#5 Ver vehiculos de un concesionario en concreto
def get_car_from_concesionario( ):
    '''
    Función para ver que coches de un concesionario en concreto, dentro de nuestra base de datos.
    
    '''
    try:
        cursor= cnx.cursor()
    
        id= input("introduzca  el id del concesionario que quieras ver los coches: ")
        query = ("select * from coche where id_concesionario ="+ str(id)+" and vendido= False ;")
        data_query= id
        cursor.execute(query, data_query)
        resultado = cursor.fetchall( ) 
        print("las coches del concesionario elegido son: ")
        for i in resultado:
            id = i[0]
            fabricante = i[1]
            tipo= i[2]
            precio = i[3]
            id_concesionario = i[4]
            vendido = i[5]
            objeto_coche= Coche(id ,fabricante,tipo, int(precio), id_concesionario,bool(vendido))
            print (objeto_coche)
            cursor.close()

    except Exception:
        return print("Se ha producido un error")  




#6.- Ver todos los coches que se han comprado mediente un contrato de leasing
def ver_coches_leasing( ):
    '''
    Función para ver que coches se han comprado mediante un contrato de leasing, dentro de nuestra base de datos.
    
    '''
    try:
        cursor = cnx.cursor()
    
        query =("select distinct c.* from contrato inner join coche c on c.id= contrato.id_coche where contrato.tipo= \"leasing\";")
        cursor.execute(query)
        resultado = cursor.fetchall( ) 
        print("las coches que se han comprado mediante un contrato leasing son: ")
        for i in resultado:
            id = i[0]
            fabricante = i[1]
            tipo= i[2]
            precio = i[3]
            id_concesionario = i[4]
            vendido = i[5]
            objeto_coche= Coche(id ,fabricante,tipo, int(precio), id_concesionario,bool(vendido))
            print (objeto_coche)

        cursor.close()
        return

    except Exception:
        return print("Se ha producido un error")  



#7.- Ver caracteristicas de un coche
def ver_caracteristicas_coche():
    '''
    Función para ver las caracteristicas de un coche, dentro de nuestra base de datos.
    
    '''
    try:
        cursor = cnx.cursor()
        id= input("introduzca el id del coche que quieres ver las caracteristicas: ")
        query =("select * from coche where id ="+ str(id)+";")
        data_query = id
        cursor.execute(query, data_query)
        resultado = cursor.fetchall( ) 
        print("las caracteristicas del coche son: ")
        for i in resultado:
            id = i[0]
            fabricante = i[1]
            tipo= i[2]
            precio = i[3]
            id_concesionario = i[4]
            vendido = i[5]
            objeto_coche= Coche(id ,fabricante,tipo, int(precio), id_concesionario, bool(vendido))
            print(objeto_coche)
        cursor.close() 
        return objeto_coche
    except Exception:
        return print("Se ha producido un error")

    


#8.- Ver informacion sobre un concesionario
def ver_info_concesionario():
    '''
    Función para ver la informacion sobre un concesionario, dentro de nuestra base de datos.
    
    '''
    try:
        cursor = cnx.cursor()

        id= input(" introduzca el id del concesionario del que quieres ver la informacion: ")
        query =("select * from concesionario where id =" + str(id)+";")
        data_query = id
        cursor.execute(query, data_query)
        resultado = cursor.fetchall( ) 
        for i in resultado:
            id = i[0]
            gerente = i[1]
            lugar= i[2]
            objeto_concesionario = Concesionario(id , gerente, lugar)

        cursor.close()   

        return objeto_concesionario

    except Exception:
        return print("Se ha producido un error")  

#9.- eliminar un mecanico
def delete_mecanico():
    '''
    Función para eliminar un mecanico, dentro de nuestra base de datos.
    
    '''
    try:
        cursor = cnx.cursor()
        query = ("Delete from mecanicos where id = %(id)s")
        id_mecanico = input("Introduce el id del mecanico que quieres eliminar: ")
        data_query = {'id':id_mecanico}
        cursor.execute(query,data_query)
        print("Mecanico eliminado")
        cnx.commit()
        cursor.close()
    except Exception:
        return print("Se ha producido un error")




#10-Dar de alta a un mecanico 
def alta_mecanico():
    '''
    Función para dar de alta aun mecanico, dentro de nuestra base de datos.
    
    '''
    try:
        cursor = cnx.cursor()
        query = ("INSERT INTO mecanicos (id, nombre, apellidos, id_taller, especialidad) VALUES (%(id)s, %(nombre)s, %(apellidos)s, %(id_taller)s,%(especialidad)s)")
        id_mecanico = input("Introduzca el id del mecanico que quieres dar de alta: ")
        nombre_mecanico = input("Introduzca el nombre del mecanico que quieres dar de alta: ")
        apellidos_mecanico = input("Introduzca el apellido del mecanico que quieres dar de alta: ")
        especialidad_mecanico = input("Introduzca la especialidad del mecanico que quieres dar de alta: ")
        id_taller_mecanico = input("Introduzca el taller del mecanico que quieres dar de alta: ")
        data_query = {'id':id_mecanico, 'nombre':nombre_mecanico, 'apellidos':apellidos_mecanico, 'id_taller':id_taller_mecanico, 'especialidad':especialidad_mecanico}
        cursor.execute(query, data_query)
        print("se añadio el mecanico")
        cnx.commit()
        cursor.close()

    except Exception:
        return print("Se ha producido un error")
    



#11 Actualizar el precio de un arreglo de un taller para aplicar un descuento del 20%

def update_price():
    '''
    Función para actualizar el precio del arreglo de un coche en concreto, dentro de nuestra base de datos.
    
    '''
    try:
        cursor = cnx.cursor()
        query = ("Update Coche_Mecanicos set precio = precio - precio*0.2 where id_coche = %(id)s")
        id_coche = input("Introduzca el id del coche arreglado que quieres hacer un descuento: ")
        data_query = {'id':id_coche}
        print("El precio del arreglo del coche seleccinaod has sido actualizado con un descuento del 20%")
        cursor.execute(query, data_query)
        cnx.commit()
    except Exception:
        return print("Se ha producido un error")
 



  

#cerrar
def disconnect():
    try:
        cnx.close()
    except Exception as e:
        return("error")


# seleccionar cliente
def get_customer():
    try:
        cursor = cnx.cursor()
        id= input("Introduce el id del cliente: ")
        query=("SELECT * from cliente where id= "+ str(id)+";")
        data_query= id
        cursor.execute(query,data_query)
        resultado = cursor.fetchall( ) 
        for i in resultado:
            id = i[0]
            nombre = i[1]
            apellido= i[2]
            dni = i[3]
            objeto_cliente= Cliente(id ,nombre,apellido, dni)
        cursor.close()
        return objeto_cliente
    except Exception:
        return print("Se ha producido un error")  

#1.-vender coche
def venderCoche(cliente, carromato, concesionario, tipo_nuevo_contrato, fecha= datetime.date.today()):
    try:
        cnx = mysql.connector.connect(host = 'localhost', user = 'root', passwd = 'Ordenador06', database = "lossantoskustoms")
        cnx.autocommit= 0 
        cursor= cnx.cursor()
        #imputs new contract
        id_contrato=input("Introduce el id del nuevo contrato: ")
        tipo=str(tipo_nuevo_contrato)
        id_cliente= cliente
        id_coche = carromato.get_id()
        id_concesionario = concesionario.get_id()
       
        # begin transaction
        
        cnx.start_transaction(consistent_snapshot=True, isolation_level= None, readonly=False) 
        query_new_contract= ("INSERT INTO `lossantoskustoms`.`contrato` (`id`, `fecha`, `tipo`, `id_cliente`, `id_coche`, `id_concesionario`) VALUES (%(id_contrato)s, %(fecha)s, %(tipo)s,%(id_cliente)s,%(id_coche)s,%(id_concesionario)s)")
        data_query_new_contract={'id_contrato':id_contrato, 'fecha':fecha.strftime("%Y-%m-%d"), 'tipo':tipo, 'id_cliente':id_cliente, 'id_coche':id_coche, 'id_concesionario':id_concesionario}
        cursor.execute(query_new_contract,data_query_new_contract)
        print("Record Updated successfully ")
        
    
        #query update coche vendido
        query_update_vendido=("UPDATE coche SET vendido = 1 WHERE coche.id=%s;")
        cursor.execute(query_update_vendido,(id_coche, ))
        print("Record Updated successfully ")
    
        cnx.commit()
        cursor.close()

    except mysql.connector.Error as error:
        print("Failed to update record to database rollback: {}".format(error))
        #reverting changes because of exception
        cnx.rollback()
    
def main ():
    try:
        show_repaired_car_mecanic()
        print("TEST 2 PASS")
    except:
        print("TEST 2 NOT PASSED")

#TEST 3
    
    try:
        show_repaired_car_garage()
        print("TEST 3 PASS")
    except:
        print("TEST 3 NOT PASSED")

#TEST 4
    
    try:
        get_car()
        print("TEST 4 PASS")
    except:
        print("TEST 4 NOT PASSED")

#TEST 5

    try:
        get_car_from_concesionario()
        print("TEST 5 PASS")
    except:
        print("TEST 5 NOT PASSED")

#TEST 6

    try:
        ver_coches_leasing()
        print("TEST 6 PASS")
    except:
        print("TEST 6 NOT PASSED")

#TEST 7

    try:
        ver_caracteristicas_coche()
        print("TEST 7 PASS")
    except:
        print("TEST 7 NOT PASSED")

#TEST 8

    try:
        ver_info_concesionario()
        print("TEST 8 PASS")
    except:
        print("TEST 8 NOT PASSED")

#TEST 9

    try:
        delete_mecanico()
        print("TEST 9 PASS")
    except:
        print("TEST 9 NOT PASSED")

#TEST 10
    
    try:
        alta_mecanico()
        print("TEST 10 PASS")
    except:
        print("TEST 10 NOT PASSED")
    
# TEST 11

    try:
        update_price()
        print("TEST 10 PASS")
    except:
        print("TEST 10 NOT PASSED") 


if __name__ == "__main__":
  main()



