# -*- coding: utf-8 -*-
class Concesionario():
    
    def __init__(self, id, empleados, lugar):
        self.__id = id
        self.__empleados = empleados
        self.__lugar = lugar
        
        #VARIABLES FINALES
        if not isinstance (id, int): 
            raise TypeError("Error.The id must be an integer")
        elif id <=0: 
            raise ValueError("Error.The id cannot be a negative number and 0")
        else:   
            self.__id= id
        
        if not isinstance(empleados, str): 
            raise TypeError("Error. empleados should be strings")
        else: 
            self.__empleados= empleados 

        if not isinstance(lugar, str): 
            raise TypeError("Error. lugar should be strings")
        else: 
            self.__lugar= lugar
        
    def __str__(self):
        return "ID: "+ str(self.__id) + "\templeado: " + str(self.__empleados) + "\tlugar:" + str(self.__lugar) 

    
    def get_id(self):
        '''
        Funcion que permiten acceder al valor de un atributo.
        :param self: se refiere al objeto instanciado de esa clase sobre el cual se está invocando dicho método.
        '''
        return self.__id