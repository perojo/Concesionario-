import mysql.connector
import datetime
from cliente import Cliente
from coche import Coche
from concesionario import Concesionario
from tipo_contract import TipoContract
import persistence



def venderCoche(cliente, carromato, concesionario, tipo_nuevo_contrato, fecha= datetime.date.today()):

    try:
        cnx = mysql.connector.connect(host = 'localhost', user = 'root', passwd = 'Ordenador06', database = "lossantoskustoms")
        cnx.autocommit= 0 
        cursor= cnx.cursor()
        #imputs new contract
        id_contrato=input("Introduce el id del nuevo contrato: ")
        tipo=str(tipo_nuevo_contrato)
        id_cliente= cliente.get_id()
        id_coche = carromato.get_id( )
        id_concesionario = concesionario.get_id()
       
        # begin transaction
        
        cnx.start_transaction(consistent_snapshot=True, isolation_level= None, readonly=False) 
        query_new_contract= ("INSERT INTO `lossantoskustoms`.`contrato` (`id`, `fecha`, `tipo`, `id_cliente`, `id_coche`, `id_concesionario`) VALUES (%(id_contrato)s, %(fecha)s, %(tipo)s,%(id_cliente)s,%(id_coche)s,%(id_concesionario)s)")
        data_query_new_contract={'id_contrato':id_contrato, 'fecha':fecha.strftime("%Y-%m-%d"), 'tipo':tipo, 'id_cliente':id_cliente, 'id_coche':id_coche, 'id_concesionario':id_concesionario}
        cursor.execute(query_new_contract,data_query_new_contract)
        print("Record Updated successfully ")
        
    
        #query update coche vendido
        query_update_vendido=("UPDATE coche SET vendido = 1 WHERE coche.id=%s;")
        cursor.execute(query_update_vendido,(id_coche, ))
        print("Record Updated successfully ")
    
        cnx.commit()
        cursor.close()

    except mysql.connector.Error as error:
        print("Failed to update record to database rollback: {}".format(error))
        #reverting changes because of exception
        cnx.rollback()
    

cliente= persistence.get_customer()
carromato= persistence.ver_caracteristicas_coche()
concesionario= persistence.ver_info_concesionario()


def main ():
    tipo_nuevo_contrato= input("  LEASING = 1 \n RENTING = 2 \n FINANCING = 3 \n FACTORING = 4 \n Introduce el tipo de contrato: ")
    tipo_contrato= TipoContract.get_tipo_contrato(tipo_nuevo_contrato)
    coche= venderCoche(cliente, carromato,concesionario,tipo_contrato)
    print (coche)


if __name__ == "__main__":
  main()
