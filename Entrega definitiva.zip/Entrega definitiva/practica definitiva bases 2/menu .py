import persistence
from logging import exception
from re import A
from mysql.connector.utils import linux_distribution
from concesionario import Concesionario
from coche import Coche
from os import DirEntry
import mysql.connector
from cliente import Cliente
import datetime
from tipo_contract import TipoContract
seguir = True
def main():
    while seguir == True:
        print("==============")
        print("WELCOME TO THE PRINCIPAL MENU")
        print("==============")
        print("1.-  vender coche") 
        print("2.- Ver que coches a arreglado un mecanico en concreto")
        print("3.- Ver que coches se han arreglado en un taller")
        print("4.- ver vehiculos de toda la cadena de concesionarios")
        print("5.- Ver vehiculos de un concesionario en concreto")
        print("6.- Ver todos los coches que se han comprado mediente un contrato de leasing")
        print("7.- Ver caracteristicas de un coche")
        print("8.- Ver informacion sobre un concesionario")
        print("9.- Dar de baja un mecanico de un taller")
        print("10.- Dar de alta un mecanico de un taller")
        print("11.- Actualizar el precio de un arreglo de un taller para aplicar un descuento del 20%")
        print("0.- Exit the program")
        try:
            opcionMenuPrincipal= int(input("Please, choose an option: "))
            if opcionMenuPrincipal == 0:
                persistence.disconnect()
                break
            elif opcionMenuPrincipal == 1:
                venderCoche()
            elif opcionMenuPrincipal == 2:
                show_repaired_car_mecanic()
            elif opcionMenuPrincipal == 3:
                show_repaired_car_garage()
            elif opcionMenuPrincipal == 4:
                get_car()
            elif opcionMenuPrincipal == 5:
                get_car_from_concesionario()
            elif opcionMenuPrincipal == 6:
                ver_coches_leasing()
            elif opcionMenuPrincipal == 7:
                ver_caracteristicas_coche()
            elif opcionMenuPrincipal == 8:
                ver_info_concesionario()
            elif opcionMenuPrincipal == 9:
                delete_mecanico()
            elif opcionMenuPrincipal == 10:
                alta_mecanico()
            elif opcionMenuPrincipal == 11:
                update_price()
        
        except ValueError:
            print("la accion debe ser entre en 0 y 11")

#1 vender carro
def venderCoche():
    cliente= get_customer()
    carromato= ver_caracteristicas_coche()
    concesionario= ver_info_concesionario()
    #try:
    tipo_nuevo_contrato= input("  LEASING = 1 \n RENTING = 2 \n FINANCING = 3 \n FACTORING = 4 \n Introduce el tipo de contrato: ")
    tipo_contrato= TipoContract.get_tipo_contrato(tipo_nuevo_contrato)
    coche= persistence.venderCoche(cliente, carromato,concesionario,tipo_contrato)
    print (coche)
    
#2
def show_repaired_car_mecanic():
    try:
        coche_reparado_por_mecanico = persistence.show_repaired_car_mecanic()
        
    except Exception as e:
        print("Ha ocurrido un error", e )



#3
def show_repaired_car_garage():
    try:
        coche_reparado_en_taller = persistence.show_repaired_car_garage()
        print("Estos son los coches reparados por este mecánico", coche_reparado_en_taller)
    except Exception as e:
        print("Ha ocurrido un error", e )





#4
def get_car(): 
    
    try:
        cars = persistence.get_car()
        print("Los vehiculos de toda la cadena de concesionarios son: ", cars)
        return cars
    except Exception as e:
        print("Ha ocurrido un error", e)

#5
def get_car_from_concesionario():
    try:
        car_from_concesionario= persistence.get_car_from_concesionario()
    except Exception as e:
        print("Ha ocurrido un error", e)

#6
def ver_coches_leasing():
    try:
        coche_leasig= persistence.ver_coches_leasing()
    except Exception as e:
        print("Ha ocurrido un error", e )


#7
def ver_caracteristicas_coche():
    try:
        caracteristicas_coche= persistence.ver_caracteristicas_coche()
    except Exception as e:
        print("Ha ocurrido un error", e )

#8
def ver_info_concesionario():
    try:
        info_concesionario= persistence.ver_info_concesionario()
    except Exception as e:
        print("Ha ocurrido un error", e )

#9
def delete_mecanico():
    try:
        eliminar_mecanico = persistence.delete_mecanico()
    except Exception as e:
        print("Ha ocurrido un error", e)


#10-Dar de alta a un mecanico
def alta_mecanico():
    try:
        añadir_mecanico = persistence.alta_mecanico()
        print("El mecanico ha sido añadido")
    except Exception as e:
        print("Ha ocurrido un error", e)


#11Actualizar el precio de un arreglo de un taller para aplicar un descuento del 20%
def update_price():
    try:
        actualizar_precio = persistence.update_price()
        print("El precio ha sido actualiado con un descuento del 20%")
    except Exception as e:
        print("Ha ocurrido un error", e)

# get customer
def get_customer():
    try:
        info_cliente= persistence.get_customer()
        print("Estas son las caracteristicas del cliente: ", info_cliente)
    except Exception as e:
        print("Ha ocurrido un error", e)


if __name__ == "__main__":
    main()


