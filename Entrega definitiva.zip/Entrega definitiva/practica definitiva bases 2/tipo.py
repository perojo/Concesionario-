# -*- coding: utf-8 -*-
import enum

class Tipo(enum.Enum):
    DEPORTIVO = 1
    MONOVOLUMEN = 2
    FAMILIAR = 3
    TODOTERRENO = 4
    CONVERTIBLE = 5
    FURGONETA = 6

    def __str__(self):
        return self.name
        #+" "+ str(self.value)

    def get_tipo(self,inputstr):
        if (inputstr == "1" or inputstr.lower() == "Deportivo".lower()):
            return Tipo.DEPORTIVO
        elif (inputstr == "2" or inputstr.lower() == "Monovolumen".lower()):
            return Tipo.MONOVOLUMEN
        elif (inputstr == "3" or inputstr.lower() == "Familiar".lower()):
            return Tipo.FAMILIAR
        elif (inputstr == "4" or inputstr.lower() == "Todoterreno".lower()):
            return Tipo.TODOTERRENO
        elif (inputstr == "5" or inputstr.lower() == "Convertible".lower()):
            return Tipo.CONVERTIBLE
        elif (inputstr == "6" or inputstr.lower() == "Furgoneta".lower()):
            return Tipo.FURGONETA
        else:
            raise Exception("tipo not valid")