# -*- coding: utf-8 -*-
class Mecanico():
    def __init__(self,id, nombre, apellidos, especialidad, id_taller):
        self.__id= id
        self.__nombre= nombre
        self.__apellidos = apellidos
        self.__especialidad= especialidad
        self.__id_taller = id_taller

        #VARIABLES FINALES
        if not isinstance (id, int): 
            raise TypeError("Error.The id must be an integer")
        elif id <=0: 
            raise ValueError("Error.The id cannot be a negative number and 0")
        else:   
            self.__id= id
        if not isinstance(nombre, str): 
            raise TypeError("Error. nombre should be strings")
        else: 
            self.__nombre= nombre
        if not isinstance(apellidos, str): 
            raise TypeError("Error. apellidos should be strings")
        else:
            self.__apellidos= apellidos
        if not isinstance (id_taller, int): 
            raise TypeError("Error.The id_taller must be an integer")
        elif id<=0: 
            raise ValueError("Error.The id_taller cannot be a negative number and 0")
        else:
            self.__id_taller= id_taller
