# -*- coding: utf-8 -*-
class Cliente(): 
    
    def __init__(self, id, nombre, apellido, dni):
        self.__id = id
        self.__nombre = nombre
        self.__apellido = apellido
        self.__dni = dni

        #VARIABLES FINALES
        if not isinstance (id, int): 
            raise TypeError("Error id should be an integer")
        elif id<=0: 
            raise ValueError("Error.The id cannot be a negative number and 0")
        else:   
            self.__id= id

        if not isinstance(nombre, str): 
            raise TypeError("Error. nombre must be a string")
        else: 
            self.__nombre= nombre
            
        if not isinstance(apellido, str): 
            raise TypeError("Error. apellido must be a string")
        else: 
            self.__apellido= apellido
            
        if not isinstance(dni, str): 
            raise TypeError("Error. dni must be a string")
        else: 
            self.__dni= dni
    
    def __str__(self):
        return "ID: "+ str(self.__id) + "\tNombre: " + str(self.__nombre) + "\tApellido: " + str(self.__apellido)+ "\tDNI: " + str(self.__dni)  

    def get_id(self):
        '''
        Funcion que permiten acceder al valor de un atributo.
        :param self: se refiere al objeto instanciado de esa clase sobre el cual se está invocando dicho método.
        '''
        return self.__id